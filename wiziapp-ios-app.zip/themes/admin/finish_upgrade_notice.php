<div class="updated fade">
	<p class="wiziapp_notice_mode">
		<?php echo WiziappAdminNotices::$_notices_texts['upgrade']['content']; ?>
	</p>
</div>