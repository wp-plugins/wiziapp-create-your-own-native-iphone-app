<div id="wiziapp_active_notice" class="updated">
	<div></div>
	<div></div>
</div>