<div id="wiziapp_email_verified_message" class="error fade">
	<p class="wiziapp_notice_mode">

	</p>
		<?php echo WiziappAdminNotices::$_notices_texts['verify_email']['content']; ?>
	<p>
		<input id="wiziappHideVerify" type="button" class="button" value="Hide this message" />
	</p>
</div>