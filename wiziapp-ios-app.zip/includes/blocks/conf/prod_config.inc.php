<?php

$envSettings = array(
	'api_server' => 'api.wiziapp.com',
	'api_key' => '',
	'cdn_server' => 'c436493.r93.cf2.rackcdn.com',
	'secure_cdn_server' => 'api.wiziapp.com',
	'analytics_account' => 'UA-21481490-1',
	'installation_source' => 'prod-env',
	'wiziapp_cache_enabled' => TRUE,
);